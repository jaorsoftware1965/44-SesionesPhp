<?php  
// -----------------------------------------------------
// funciones.php
// -----------------------------------------------------

// Función para verificar si la sesión es correcta
function fnSesionValida($conexion,$numeroSesion)
{
	// Preparando el Query para la Consulta
    $query  = " SELECT TIME_TO_SEC(TIMEDIFF(fechaHoraFin,NOW())) as diferencia";
    $query .= " FROM sesiones ";
    $query .= " WHERE id = ".$numeroSesion;
    
    // Ejecuta Query y obtiene Registros
	$registros = $conexion->query($query);

   // Inicializa el Resultado
    $resultado = true;

    // Vaerifica que hay registros
	if ($registros)
	{    
        // Ciclo para procesar cada registro de usario
        if (mysqli_num_rows($registros)>0)
        { 
           // Lee un Registro
           $fila = $registros->fetch_assoc();

           // agrega los datos al resultado
           $resultado  = $fila['diferencia'];

           // Verifica si el resultado es menor que 0
           if ($resultado < 0)
           {
              // Elimina la Sesión
              $query = "DELETE FROM sesiones WHERE id = ".$numeroSesion;

              // Ejecuta Query de Borrado
              $registros = $conexion->query($query);

              // Coloca
              $resultado = false;
           }
		   else
		   {
			   // Prepara el Query para actualizar la sesión
			   $query  = "UPDATE sesiones SET fechaHora =NOW()";
			   $query .= "WHERE  id = ".$numeroSesion;

			   // Ejecuta Query de Actualizacion
			   $registros = $conexion->query($query);
		   }
        }
        else
        {
            // Cambia el Resultado
            $resultado = false;
        }
	}  
    else
	{
		// Cambia el Resultado
		$resultado = false;
	}
        
    // retorna
    return $resultado;
}
?>