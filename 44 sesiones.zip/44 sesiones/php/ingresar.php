<?php  
// -----------------------------------------------------
// ingresar.php
// -----------------------------------------------------

// Incluimos la conexion
require "conexion.php";

// Verificamos que hayan llegado los datos
if (isset($_POST['nomUsuario']) && 
	 isset($_POST['cveUsuario']) )
{
    // Obtenemos los 2 datos
    $usuario = $_POST['nomUsuario'];
    $clave   = $_POST['cveUsuario'];    

    // Preparando el Query para la Consulta
    $query  = " SELECT * FROM usuarios";
    $query .= " WHERE nombre = '".$usuario."'";
    $query .= " AND   clave  = '".$clave ."'";
    
    // Ejecuta Query y obtiene Registros
	$registros = $conexion->query($query);

    // Vaerifica que hay registros
    if ($registros)
	{    
        // Ciclo para procesar cada registro de usario
        if (mysqli_num_rows($registros)>0)
        { 
           // Genera el Numero Aleatorio para la sesion
           $numeroSesion = rand();

           // Obtiene el hostName
           $hostName = gethostname();

           // Prepara el Query para Insert
           $query = "INSERT INTO sesiones (id,hostName) VALUES(".$numeroSesion.",'".$hostName."')";

           // Ejecuta Query y obtiene Registros
	        $registros = $conexion->query($query);

           // Verifica
           if ($registros)
           {   
               // Ejecuta la Página Web Principal               
		       header("Location: ../principal.html?sesion=$numeroSesion");
           }   
           else
           {   
               // Activa la venta de error
               header("Location: ../error.html?paginaRegresar=login.html&mensaje=".mysqli_error($conexion));   
           }
        }  
        else
            // No hubo ingreso
            header("Location: ../error.html?paginaRegresar=login.html&mensaje=Error en Usuario y Clave");
	}  
    else
       // No hubo ingreso
       header("Location: ../error.html?paginaRegresar=login.html&mensaje=Error en Consulta de Usuario y Clave");

    // Imprime el Resultado
    echo $resultado;
}
else
{
   // No hubo ingreso
   header("Location: ../error.html?paginaRegresar=login.html&mensaje=Faltaron datos ...");
}

?>