<?php  
// -----------------------------------------------------
// cargarSesiones.php
// -----------------------------------------------------

// Incluimos la conexion
require "conexion.php";

// Incluimos el archivo de funciones
require "funciones.php";

// Verificamos que hayan llegado los datos
if (isset($_GET['numSesion']))
{
    // Obtiene el dato de la sesion
	$sesion = $_GET['numSesion'];    

    // Verifica que la sesión sea valida primero
	if (fnSesionValida($conexion,$sesion))
    {
        
        // Preparando el Query para la Consulta
        $query = "SELECT * FROM sesionesVariables ORDER BY sesion, nombre";

        // Ejecuta Query y obtiene Registros
        $registros = $conexion->query($query);

        // Vaerifica que hay registros
        if ($registros)
        {   
            // Crea los encabezados de la tabla
            echo "<tr>\n";
            echo "  <th>Sesion</th>\n";
            echo "  <th>Variable</th>\n";
            echo "  <th>Valor</th>\n";
            echo "</tr>\n";

            // Ciclo para procesar cada registro de usario
            while ($fila = $registros->fetch_assoc()) 
            { 
                // Crea el Renglon html 
                echo "<tr>\n";
                
                // Coloca los datos para cada columna
                echo "   <td>".$fila['sesion']."</td>\n";
                echo "   <td>".$fila['nombre']."</td>\n";
                echo "   <td>".$fila['valor']."</td>\n";

                // Cierra el Renglon html 
                echo "</tr>\n";

            }
        }
        else
        {
            // Devuelve el mensaje de conexion
            echo $conexion->error();
        }
    }
    else
    {     
        // Mensaje
        Echo "La Sesion ya no es valida";
    }
}
else
{
    // Mensaje de Error
    echo "Intento de Acceso No valido";
}
?>